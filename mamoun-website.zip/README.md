# mamoun-website
training app for node js by Mamoun Hourani
Reached video #9 on youtube node crash course
last statement: 
created model for blog and connected to to the database
now the user may access all blogs from localhost:3000/all-blogs
the user also may find all blogs inside index through : localhost:3000