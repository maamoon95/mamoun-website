const {people , ages , jops} = require('./people');
console.log(ages , jops);
const os = require ('os');
console.log(os.platform() , os.homedir());