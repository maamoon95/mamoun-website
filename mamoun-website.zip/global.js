// global test


//global.setTimeout(() => {
  //  console.log('3 seconds passed')
//clearInterval(int);

//}, 3000);
//
//const int = setInterval(() => {
  //  console.log('مرت نصف ثانية');
//}, 500);

console.log(__dirname);
console.log(__filename);
