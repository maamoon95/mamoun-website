const name = 'mamoun';

console.log(name);
