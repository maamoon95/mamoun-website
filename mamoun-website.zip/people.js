const people = ['mamoon','zawawy','m7md','a7md'];
const ages = ['23', '19', '15' , '27'];
const jops = ['dentist' , 'instructors' , 'dancer' , 'nothing'];
console.log(people);
module.exports = {
people , ages , jops
};